<html>
    <link rel="stylesheet" href="estilos.css">
    <body>
        <div id="menu">
            <a href="insertarContacto.php">Inserta Contacto</a><br><br>
            <a href="listarContactos.php">Listado de contactos</a>
        </div>
    </body>
</html>